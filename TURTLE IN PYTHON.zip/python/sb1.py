import turtle as turtle_module
import random

turtle_module.colormode(255)
tim = turtle_module.Turtle()
tim.speed("fastest")  # Corrected speed
tim.penup()
tim.hideturtle()

colors = [(212, 166, 152), (91, 88, 219), (49, 133, 2), (83, 148, 191), (23, 195, 54),
          (108, 162, 190), (202, 58, 227), (177, 170, 100), (78, 224, 201), (164, 21, 180)]

tim.setheading(255)
tim.forward(300)
tim.setheading(0)

number_of_dots = 100
for dot_count in range(1, number_of_dots + 1):
    tim.dot(20, random.choice(colors))
    tim.forward(50)

    if dot_count % 10 == 0:
        tim.setheading(90)
        tim.forward(50)
        tim.setheading(180)
        tim.forward(500)
        tim.setheading(0)

# Corrected Screen function
screen = turtle_module.Screen()
screen.exitonclick()
